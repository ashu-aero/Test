package com.nms;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.query.QueryLookupStrategy.Key;
import org.springframework.data.repository.support.Repositories;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class AppController {

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private DeviceRepository deviceRepo;

	@GetMapping("/")
	public String loginScreen(HttpSession session) {
		session.removeAttribute("username");

		return "login";
	}

	@GetMapping("/logout")
	public String logoutScreen(ModelMap modelMap, HttpSession session) {
		session.removeAttribute("username");
		modelMap.addAttribute("logout", "Logged out Successfully.");
		return "login";
	}

	/*
	 * @GetMapping("/") public String loginScreen( ) {
	 * 
	 * Authentication authentication =
	 * SecurityContextHolder.getContext().getAuthentication(); if (authentication ==
	 * null || authentication instanceof AnonymousAuthenticationToken) { return
	 * "login"; }
	 * 
	 * return "redirect:/home"; }
	 */

	@GetMapping("/home")
	public String homeScreen(Model model, HttpSession session) {
		boolean reachable = false;
		if (session.getAttribute("username") != null) {
			List<Device> deviceList = deviceRepo.findAll();
			 

			model.addAttribute("deviceList", deviceList);
			return "home";
		} else {
			return "redirect:/";
		}

	}

	@GetMapping("/device_list")
	public String deviceList(Model model, HttpSession session) {
		if (session.getAttribute("username") != null && session.getAttribute("username").toString().equals("admin")) {
			List<Device> deviceList = deviceRepo.findAll();
			model.addAttribute("deviceList", deviceList);
			return "deviceList";
		} else {
			return "redirect:/";
		}
	}

	@GetMapping("/device_delete")
	public String deviceDelete(Model model, HttpSession session, @Param("id") String id) {

		if (session.getAttribute("username") != null && session.getAttribute("username").toString().equals("admin")) {

			deviceRepo.deleteById(Long.parseLong(id));

			List<Device> deviceList = deviceRepo.findAll();
			model.addAttribute("deviceList", deviceList);
			return "deviceList";
		} else {
			return "redirect:/";
		}
	}

	@GetMapping("/device_edit")
	public String deviceEdit(Model model, HttpSession session, @Param("id") String id) {

		if (session.getAttribute("username") != null && session.getAttribute("username").toString().equals("admin")) {

			Device device = deviceRepo.getOne(Long.parseLong(id));

			List<Device> deviceList = deviceRepo.findAll();
			model.addAttribute("device", device);
			return "edit_device";
		} else {
			return "redirect:/";
		}
	}

	@GetMapping("/update_device")
	public String updateRegister(Device device, ModelMap modelMap, Model model, HttpSession session) {

		if (session.getAttribute("username") != null && session.getAttribute("username").toString().equals("admin")) {
			deviceRepo.save(device);

			modelMap.addAttribute("update", "Device updated Successfully.");

			List<Device> deviceList = deviceRepo.findAll();
			model.addAttribute("deviceList", deviceList);
			return "deviceList";
		} else {
			return "redirect:/";
		}

	}

	@GetMapping("/add_device")
	public String addIp(HttpSession session) {

		if (session.getAttribute("username") != null) {
			return "add_device";
		} else {
			return "redirect:/";
		}

	}

	@GetMapping("/register")
	public String showRegistrationForm(Model model) {
		model.addAttribute("user", new User());

		return "signup_form";
	}

	@RequestMapping(value = "/process_register", method = RequestMethod.POST)

	// @GetMapping("/process_register")
	public String processRegister(User user, ModelMap modelMap, HttpSession session) {

		String username = user.getUsername();

		User u = userRepo.findUserByUserName(username);
		if (u != null) {
			modelMap.addAttribute("message", "This user has been already registered.");
			return "/signup_form";
		} else {
			BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
			String encodedPassword = passwordEncoder.encode(user.getPassword());
			user.setPassword(encodedPassword);
			userRepo.save(user);
			modelMap.addAttribute("success", "you have  registered Successfully.");
			return "/login";
		}

	}

	@RequestMapping(value="/add_device" , method=RequestMethod.POST)
	public String deviceRegister(Device device, ModelMap modelMap, HttpSession session) {

		if (session.getAttribute("username") != null) {
			device.setStatus(false);
			deviceRepo.save(device);

			modelMap.addAttribute("msg", "Device added Successfully.");

			return "add_device";
		} else {
			return "redirect:/";
		}

	}

	@RequestMapping(value = "/process_login", method = RequestMethod.POST)
	public String processLogin(User user, @Param("username") String username, @Param("password") String password,
			HttpSession session, ModelMap modelMap) {

		
		String unknownUsername = username;
		String unknownPlainPassword = password;

		BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();

		User actualUser = userRepo.findUserByUserName(unknownUsername);

		if (actualUser != null) {
				String usernameActual = actualUser.getUsername();
				String encodedPassword = actualUser.getPassword();
				boolean isMatched = bCryptPasswordEncoder.matches(unknownPlainPassword, encodedPassword);
				if (isMatched) {
					session.setAttribute("username", usernameActual);
					session.setAttribute("name", actualUser.getName());
					return "redirect:home";
				} 
				else {
					 modelMap.addAttribute("error","Invalid Password.");
					return "login";
				}
		} 
		else
		{
			
				modelMap.addAttribute("error", "This username is not registered here. Please try with registered Username.");
				return "login";
		}

	}

	@RequestMapping(value = "/test_json_api", produces = "application/json", method = RequestMethod.GET)
	@ResponseBody
	public Map<Integer, Device> test_json_api() {
		List<Device> deviceList = deviceRepo.findAll();
		Map<Integer, Device> deviceMap = new HashMap<>();
		for (int i = 0; i < deviceList.size(); i++) {
			deviceMap.put((i + 1), deviceList.get(i));
		}

		return deviceMap;
	}
	
	
    
}

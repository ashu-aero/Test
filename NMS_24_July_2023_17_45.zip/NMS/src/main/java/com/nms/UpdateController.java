package com.nms;

import java.net.InetAddress;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.query.QueryLookupStrategy.Key;
import org.springframework.data.repository.support.Repositories;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import ch.qos.logback.core.net.SyslogOutputStream;

@Controller
public class UpdateController {

	@Autowired
	private DeviceRepository deviceRepo;
	
	@Autowired
	private StatusRepository statusRepo;

	@GetMapping("/start_update")
	public String starUpdate(ModelMap modelMap, Model model, HttpSession session) {
		if (session.getAttribute("username") != null && session.getAttribute("username").toString().equals("admin")) { 			
			updateDeviceTable();			
			updateStatusTable();			
			modelMap.addAttribute("msg", "Status Update Methods started Successfully.");
			return "login";
		} else {
			modelMap.addAttribute("msg", "You are not an administrator of this application.");
			return "login";
		}

	}
 
	 
	
	
	
	
	private void updateDeviceTable() {
		Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {          	
            	List<Device> deviceList = deviceRepo.findAll();
    			for (int i = 0; i < deviceList.size(); i++) {
    				Device device=deviceList.get(i);
    				String ip = device.getIp_address();
    				try {
    					InetAddress address = InetAddress.getByName(ip);
    					Boolean reachable = address.isReachable(500);
    					 
    					if(device.isStatus()&&reachable) {
    						
    					}
    					else if((!device.isStatus())&&reachable) {
    						device.setStatus(true);
    						deviceRepo.save(device);    						 
    					}
    					else if(device.isStatus()&&(!reachable)) {
    						device.setStatus(false);
    						deviceRepo.save(device);    						
    					}
    				} catch (Exception e) {
    					e.printStackTrace();
    				}	    				 

    			}

    			 

            }
        }, 0, 10000);
	}
	 
	
	private void updateStatusTable() {
		Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {          	
            	List<Device> deviceList = deviceRepo.findAll();
    			for (int i = 0; i < deviceList.size(); i++) {
    				Device device=deviceList.get(i);
    				String ip = device.getIp_address();
    				try {
    					InetAddress address = InetAddress.getByName(ip);
    					Boolean reachable = address.isReachable(500);
    					  
    					if(reachable) {
    						Status status=statusRepo.findByIpWhoseisDown(ip);
    						if(status!=null) {
    							Timestamp utimestamp = new Timestamp(System.currentTimeMillis());
        						status.setUtimestamp(utimestamp);
        						statusRepo.save(status);
    						}    						
    					} 
    					else if(!reachable) {
    						Status status=statusRepo.findByIpWhoseisDown(ip);
    						if(status==null) {
    							status=new Status();
        						status.setIp_address(ip);
        						Timestamp dtimestamp = new Timestamp(System.currentTimeMillis());
        						status.setDtimestamp(dtimestamp);
        						statusRepo.save(status);
    						}
    						
    						
    					}
    				} catch (Exception e) {
    					e.printStackTrace();
    				}	    				 

    			}

    			 

            }
        }, 0, 10000);
	}
	 
	
    
}
